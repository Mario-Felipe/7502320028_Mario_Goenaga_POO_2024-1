package Crud;

public class FuerzaLaboralCrud {
    
}
