package Crud;

public class RutaTrabajoCrude {
    
}
